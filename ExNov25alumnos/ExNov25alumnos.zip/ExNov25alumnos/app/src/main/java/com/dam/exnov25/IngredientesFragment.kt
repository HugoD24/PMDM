package com.dam.exnov25

import androidx.fragment.app.Fragment


class IngredientesFragment() : Fragment() {

}